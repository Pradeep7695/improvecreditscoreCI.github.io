<?php $page = 'dashboard'; include APPPATH ."views/admin/template/head.php";?>

<?php include APPPATH ."views/admin/template/navigation.php";?>

<?php include APPPATH ."views/admin/template/header.php";?>

<!-- ------------------maine content start here --------------- -->

<ul class="breadcrumb">
	<li><a href="#">Home</a></li>
	<li class="active">Dashboard</li>
</ul>

<div class="page-content-wrap">
    <div class="row">
		<div class="main-dash">
			<div class="imgsec">
				<img src="<?= base_url('assets/admin/img/home-travel-logo.png')?>">
			</div>
			<!--<div class="dash-text">
				<p class="text-top">
					Welcome To
				</p>
				<p class="text-2">
					The Travel Firm
				</p>
			</div>-->
		</div>
	</div>
</div>


<!-- ---------------..//end main content ----------------- -->

<?php include APPPATH ."views/admin/template/footer.php";?>
